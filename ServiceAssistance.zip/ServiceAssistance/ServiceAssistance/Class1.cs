﻿using System;
using System.DirectoryServices.AccountManagement;
using System.ServiceProcess;
using System.Activities;
using System.Activities.Presentation.Metadata;
using System.ComponentModel;
using System.Collections.Generic;

namespace ServiceAssistance
{
    [DisplayName("Stop Service")]
    public class StopService : CodeActivity
    {
        //StopService("UiRobotSvc");
        [Category("Input")]
        [RequiredArgument]
        [DisplayName("Service Name")]
        public InArgument<string> sName { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            ServiceController myService = new ServiceController();
            //myService.ServiceName = "UiRobotSvc";
            myService.ServiceName = sName.Get(context);
            string svcStatus = myService.Status.ToString();
            if (svcStatus == "Running")
            {
                myService.Stop();
            }
        }


    }

    [DisplayName("Start Service")]
    public class StartService : CodeActivity
    {
        //StopService("UiRobotSvc");
        [Category("Input")]
        [RequiredArgument]
        [DisplayName("Service Name")]
        public InArgument<string> sName { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            ServiceController myService = new ServiceController();
            myService.ServiceName = sName.Get(context);
            string svcStatus = myService.Status.ToString();
            if (svcStatus == "Stopped")
            {
                myService.Start();
            }
        }


    }
}



