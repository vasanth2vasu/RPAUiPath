﻿using System;
using System.DirectoryServices.AccountManagement;
using System.ServiceProcess;
using System.Activities;
using System.Activities.Presentation.Metadata;
using System.ComponentModel;
using System.Collections.Generic;

namespace PasswordUtilityCustomActivity
{
    public class ChangePwd : CodeActivity

    {
        [Category("Input")]
        [RequiredArgument]
        [DisplayName("domain")]
        public InArgument<string> domain { get; set; }

        [Category("Input")]
        [RequiredArgument]
        [DisplayName("userName")]
        public InArgument<string> userName { get; set; }

        [Category("Input")]
        [RequiredArgument]
        [DisplayName("oldPassword")]
        public InArgument<string> oldPassword { get; set; }

        [Category("Input")]
        [RequiredArgument]
        [DisplayName("newPassword")]
        public InArgument<string> newPassword { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            using (var context1 = new PrincipalContext(ContextType.Domain, domain.Get(context)))
            using (var user = UserPrincipal.FindByIdentity(context1, IdentityType.SamAccountName, userName.Get(context)))

            {
                user.ChangePassword(oldPassword.Get(context), newPassword.Get(context));
            }
        }
    }
}

